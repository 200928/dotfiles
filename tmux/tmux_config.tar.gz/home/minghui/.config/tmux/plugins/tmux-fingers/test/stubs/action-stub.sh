#!/usr/bin/env bash

input=$(cat)
echo "action-stub => $input" > /tmp/fingers-stub-output
